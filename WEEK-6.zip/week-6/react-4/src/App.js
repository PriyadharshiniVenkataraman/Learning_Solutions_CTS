import logo from './logo.svg';
import './App.css';
import Posts from './posts';

function App() {
  return (
    <div className="App">
      <Posts/>
    </div>
  );
}

export default App;
