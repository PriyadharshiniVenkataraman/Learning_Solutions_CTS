
import React from "react";
function Contact()
{
    return <h1>
        Welcome to the contact page of student management portal
    </h1>
}
export default Contact;