
import React from "react";

function Home(){
    return <h1>Welcome to the home page of student management portal</h1>
}

export default Home;